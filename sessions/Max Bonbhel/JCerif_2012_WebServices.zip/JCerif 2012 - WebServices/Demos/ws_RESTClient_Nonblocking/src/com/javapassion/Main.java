package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main extends Activity {

    String response;
    private Handler mHandler;
    EditText mEditText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mEditText = (EditText) findViewById(R.id.edit_text);       
        final Button mButton = (Button) findViewById(R.id.button);

        mButton.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
            	// Create Handler object for displaying the result
            	// later on.
            	mHandler = new Handler();
                // Start a new thread for performing web service
                // invocation.            	
            	checkUpdate.start();
            }
        });
    }
    
    // A separate thread that performs the Web service invocation
    private Thread checkUpdate = new Thread() {
        public void run() {
            try {
            	response = RESTClient.callRESTService(mEditText.getText().toString());
                mHandler.post(showUpdate);
            } catch (Exception e) {
            }
        }
    };

    private Runnable showUpdate = new Runnable(){
       	public void run(){
    	    Toast.makeText(Main.this, "HTML Code: " + response, Toast.LENGTH_LONG).show();
        }
    };    
    
}
package com.javapassion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main extends Activity {

    String response;

    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        final EditText mEditText = (EditText) findViewById(R.id.edit_text); 
   
        // There is a problem in escaping the & in string resource as described below.
        // So instead of specifying it in the strings.xml, we are hard-coding it here.
        // https://appcelerator.lighthouseapp.com/projects/32238/tickets/1952-android-escaped-ampersand-in-uri-query-string-gets-unescaped-thus-breaking-xhr-calls
        // We are setting manually in the code instead of string resource just to get by.
        mEditText.setText("http://ws.geonames.org/citiesJSON?north=44.1&south=-9.9&east=-22.4&west=55.2&lang=de");
        
        //mEditText.setText("http://localhost:8080/AuctionApp/resources/sellers/1");
        
        final Button mButton = (Button) findViewById(R.id.button);
        final TextView mTextView = (TextView) findViewById(R.id.content);

        mButton.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                try {
                    response = RESTClient.callRESTService(mEditText.getText().toString());
                } catch (Exception e) {
                    response = getString(R.string.error_message);
                    e.printStackTrace();
                }
                mTextView.setText(response);
            }
        });
    }
}